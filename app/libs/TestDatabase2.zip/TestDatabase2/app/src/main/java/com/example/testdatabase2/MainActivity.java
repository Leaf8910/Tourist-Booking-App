package com.example.testdatabase2;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Toast;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import android.os.AsyncTask;

public class MainActivity extends AppCompatActivity {
    private Connection connection;

    private EditText editTextUsername;
    private EditText editTextPassword;
    private Button buttonLogin;

//    @SuppressLint("NewApi")
//    public Connection connectionclass() throws SQLException {
//        Connection con = null;
//        String ip = "192.168.100.20", port = "1433", username = "sa", password = "1234", databasename = "seoulstay";
//        StrictMode.ThreadPolicy tp = new StrictMode.ThreadPolicy.Builder().permitAll().build();
//
//
//
//        StrictMode.setThreadPolicy(tp);
//        try {
//            Class.forName("net.sourceforge.jtds.jdbc.Driver");
//            String connectionUrl = "jdbc:jtds:sqlserver://" + ip + ":" + port + ";databasename=" + databasename + ";User=" + username + ";password=" + password + ";";
//            con = DriverManager.getConnection(connectionUrl);
//        } catch (Exception exception) {
//            Log.e("Error", exception.getMessage());
//        }
//        return con;
//    }
    public void openSecondActivity(){
        Intent intent = new Intent(this, SecondActivity.class);
        startActivity(intent);
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextUsername = findViewById(R.id.editTextUsername);
        editTextPassword = findViewById(R.id.editTextPassword);
        buttonLogin = findViewById(R.id.buttonLogin);
//        TextView id = (TextView) findViewById(R.id.edittextid);
//        TextView name = (TextView) findViewById(R.id.edittextname);
//        TextView address = (TextView) findViewById(R.id.edittextaddress);
//        Button btninsert = (Button) findViewById(R.id.btnadd);
//        Button btnupdate = (Button) findViewById(R.id.btnupdate);
//        Button btndelete = (Button) findViewById(R.id.btndelete);
//        Button btnget = (Button) findViewById(R.id.btnget);
        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("StaticFieldLeak")
            public void onClick(View v) {
                String username = editTextUsername.getText().toString();
                String password = editTextPassword.getText().toString();
        new AsyncTask<Void, Void, Boolean>() {
//            @Override


            protected Boolean doInBackground(Void... voids) {
                Connection connection = null;
                try {
                    Class.forName("net.sourceforge.jtds.jdbc.Driver");
                    connection = DriverManager.getConnection("jdbc:jtds:sqlserver://192.168.100.20:1433/seolstay", "sa", "1234");

                    String query = "SELECT * FROM login WHERE username = ? AND password = ?";
                    PreparedStatement statement = connection.prepareStatement(query);
                    statement.setString(1, username);
                    statement.setString(2, password);
                    ResultSet resultSet = statement.executeQuery();

                    if (resultSet.next()) {
                        return true; // Login successful
                    } else {
                        return false; // Invalid credentials
                    }
                } catch (ClassNotFoundException | SQLException e) {
                    e.printStackTrace();
                } finally {
                    if (connection != null) {
                        try {
                            connection.close();
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                    }
                }
                return false; // Error occurred
            }

//            @Override
            protected void onPostExecute(Boolean loginResult) {
                if (loginResult) {
                    Toast.makeText(MainActivity.this, "Login successful", Toast.LENGTH_SHORT).show();
                    openSecondActivity();
                } else {
                    Toast.makeText(MainActivity.this, "Invalid credentials", Toast.LENGTH_SHORT).show();
                }
            }
        }.execute();
    };
});};}










//        buttonLogin.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                String username1 = editTextUsername.getText().toString();
//                String password1 = editTextPassword.getText().toString();
//// Establish a connection to the SQL database
//                Connection connection = null;
//                try {
//                    Class.forName("net.sourceforge.jtds.jdbc.Driver");
//                    connection = DriverManager.getConnection("jdbc:jtds:sqlserver://192.168.100.20:1433/seoulstay", "sa", "1234");
//
//                    // Execute a query to check if the provided username and password match a user in the database
//                    String query = "SELECT * FROM login WHERE username = ? AND password = ?";
//                    PreparedStatement statement = connection.prepareStatement(query);
//                    statement.setString(1, username1);
//                    statement.setString(2, password1);
//                    ResultSet resultSet = statement.executeQuery();
//
//                    if (resultSet.next()) {
//                        // Login successful
//                        Toast.makeText(MainActivity.this, "Login successful", Toast.LENGTH_SHORT).show();
//                        openSecondActivity();
//                    } else {
//                        // Invalid credentials
//                        Toast.makeText(MainActivity.this, "Invalid credentials", Toast.LENGTH_SHORT).show();
//                    }
//
//                    // Close the resources
//                    resultSet.close();
//                    statement.close();
//
//                } catch (ClassNotFoundException | SQLException e) {
//                    e.printStackTrace();
//                } finally {
//                    if (connection != null) {
//                        try {
//                            connection.close();
//                        } catch (SQLException e) {
//                            e.printStackTrace();
//                        }
//                    }
//

















//                String query = "SELECT * FROM login WHERE username = ? AND password = ?";
//                PreparedStatement statement = connection.prepareStatement(query);
//                statement.setString(1, username1);
//                statement.setString(2, password1);
//                ResultSet resultSet = statement.executeQuery();
//                // Placeholder logic to show a toast message based on the login result
////                if (username.equals("username") && password.equals("password")) {
////                    Toast.makeText(MainActivity.this, "Login successful", Toast.LENGTH_SHORT).show();
////                    openSecondActivity();
////                } else {
////                    Toast.makeText(MainActivity.this, "Invalid credentials", Toast.LENGTH_SHORT).show();
////                }
//                try {
//                    if (resultSet.next()) {
//                        // Login successful
//                        Toast.makeText(MainActivity.this, "Login successful", Toast.LENGTH_SHORT).show();
//                        openSecondActivity();
//                    } else {
//                        // Invalid credentials
//                        Toast.makeText(MainActivity.this, "Invalid credentials", Toast.LENGTH_SHORT).show();
//                    }
//                } catch (SQLException e) {
//                    throw new RuntimeException(e);
//                }
//                openSecondActivity();

//                Connection connection = connectionclass();
//                try {
//                    if (connection != null) {
//                        String sqlinsert = "Insert into register values ('" + id.getText().toString() + "','" + name.getText().toString() + "','" + address.getText().toString() + "')";
//                        Statement st = connection.createStatement();
//                        ResultSet rs = st.executeQuery(sqlinsert);
//                    }
//                } catch (Exception exception) {
//                    Log.e("Error", exception.getMessage());
//                }
//            }
//        };




        // Establish the database connection
//        connectDatabase();

        // Perform database operations
//        retrieveData();

        // Close the database connection
//        disconnectDatabase();
//    });}}

//    private void connectDatabase() {
//        String url = "jdbc:mysql://172.1.1.0:54854/register_singapore2";
//        String username = "sa";
//        String password = "1234";
//
//        try {
//            Class.forName("com.mysql.cj.jdbc.Driver");
//            connection = DriverManager.getConnection(url, username, password);
//        } catch (ClassNotFoundException e) {
//            e.printStackTrace();
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//
//    }

//    private void retrieveData() {
//        try {
//            if (connection != null) {
//                Statement statement = connection.createStatement();
//                ResultSet resultSet = statement.executeQuery("SELECT * FROM register");
//
//                while (resultSet.next()) {
//                    // Process each row of data
//                    String data = resultSet.getString("username");
//                    // Output the data to the console or update your UI
//                    Log.d("Data", data);
//                }
//
//                resultSet.close();
//                statement.close();
//            }else {
//                Log.e("Database", "Connection is Null");
//            }
//            } catch(SQLException e){
//                e.printStackTrace();
//            }
//        }


//    private void disconnectDatabase() {
//        try {
//            if (connection != null && !connection.isClosed()) {
//                connection.close();
//            }
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//    }
//}
